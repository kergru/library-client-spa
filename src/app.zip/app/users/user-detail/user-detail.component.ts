import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { UsersService } from '../users.service';
import { User } from '../user.model';

@Component({
  selector: 'app-user-detail',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    @if (loading) {
      <div>Lade Benutzerdaten...</div>
    } @else if (error) {
      <div style="color: red">{{ error }}</div>
    } @else {
      <div class="user-detail">
        <h2>{{ user?.username || 'Unbekannter Benutzer' }}</h2>
        <p><strong>ID:</strong> {{ user?.id || 'N/A' }}</p>
        <p><strong>Email:</strong> {{ user?.email || 'N/A' }}</p>
        <p><strong>Rollen:</strong> {{ user?.roles?.join(', ') || 'Keine Rollen' }}</p>
      </div>
    }
  `,
  styles: [`
    .user-detail {
      max-width: 600px;
      margin: 20px auto;
      padding: 20px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
  `]
})
export class UserDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private usersService = inject(UsersService);

  user: User | null = null;
  loading = false;
  error: string | null = null;

  ngOnInit(): void {
    this.loadUser();
  }

  private loadUser(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (!id) {
      this.error = 'Keine Benutzer-ID angegeben';
      return;
    }

    this.loading = true;
    this.usersService.getUser(id).subscribe({
      next: (user) => {
        this.user = user;
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Fehler beim Laden der Benutzerdaten';
        this.loading = false;
        console.error('Fehler beim Laden des Benutzers:', err);
      }
    });
  }
}
