import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { UsersService } from '../users.service';
import { User } from '../user.model';

@Component({
  selector: 'app-users-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="users-container">
      <h2>Benutzerverwaltung</h2>

      @if (loading) {
        <div class="loading">Benutzer werden geladen...</div>
      } @else if (error) {
        <div class="error">{{ error }}</div>
      } @else {
        @if (users.length > 0) {
          <ul class="users-list">
            @for (user of users; track user.id) {
              <li class="user-item">
                <a [routerLink]="['/admin/users', user.id]" class="user-link">
                  {{ user.username || 'Unbekannter Benutzer' }}
                </a>
                <span class="user-email">({{ user.email || 'Keine E-Mail' }})</span>
              </li>
            }
          </ul>
        } @else {
          <p>Keine Benutzer gefunden.</p>
        }
      }
    </div>
  `,
  styles: [`
    .users-container {
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
    }

    .loading {
      color: #666;
      font-style: italic;
      margin: 20px 0;
    }

    .error {
      color: #d32f2f;
      background-color: #ffebee;
      padding: 10px;
      border-radius: 4px;
      margin: 10px 0;
    }

    .users-list {
      list-style: none;
      padding: 0;
    }

    .user-item {
      padding: 12px 0;
      border-bottom: 1px solid #eee;
      display: flex;
      align-items: center;
    }

    .user-link {
      text-decoration: none;
      color: #1976d2;
      font-weight: 500;

      &:hover {
        text-decoration: underline;
      }
    }

    .user-email {
      color: #666;
      margin-left: 8px;
      font-size: 0.9em;
    }
  `]
})
export class UsersListComponent implements OnInit {
  private usersService = inject(UsersService);

  users: User[] = [];
  loading = false;
  error: string | null = null;

  ngOnInit(): void {
    this.loadUsers();
  }

  private loadUsers(): void {
    this.loading = true;
    this.usersService.getUsers().subscribe({
      next: (users) => {
        this.users = users || [];
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Fehler beim Laden der Benutzerliste';
        this.loading = false;
        console.error('Fehler beim Laden der Benutzer:', err);
      }
    });
  }
}
