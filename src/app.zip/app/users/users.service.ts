import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './user.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class UsersService {
  private http = inject(HttpClient);

  private base = environment.apiBaseUrl + '/admin/users';

  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(this.base);
  }

  getUser(id: string): Observable<User> {
    return this.http.get<User>(`${this.base}/${id}`);
  }
}
