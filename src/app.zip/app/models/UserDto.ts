export interface UserDto {
  userName: string;
  firstName: string;
  lastName: string;
  email: string;
}
