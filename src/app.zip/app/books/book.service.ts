import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Book } from './book.model';
import { environment } from '../../environments/environment';

@Injectable({providedIn:'root'})
export class BookService {
  private http = inject(HttpClient);

  private base = environment.apiBaseUrl + '/books';
  getBooks(): Observable<Book[]> { return this.http.get<Book[]>(this.base); }
  getBook(isbn: string): Observable<Book> { return this.http.get<Book>(`${this.base}/${encodeURIComponent(isbn)}`); }
}
