import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { BookService } from '../book.service';
import { Book } from '../book.model';
import { Observable, catchError, of, startWith, map } from 'rxjs';

interface BooksState {
  loading: boolean;
  error: string | null;
  books: Book[];
}

@Component({
  selector: 'app-books-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './books-list.component.html',
  styleUrls: ['./books-list.component.css']
})
export class BooksListComponent {
  private bookService = inject(BookService);

  state$: Observable<BooksState>;

  constructor() {
    this.state$ = this.bookService.getBooks().pipe(
      map((books) => ({
        loading: false,
        error: null,
        books: books || []
      })),
      catchError((err) => {
        console.error('Fehler beim Laden der Bücher:', err);
        return of({
          loading: false,
          error: 'Fehler beim Laden der Bücherliste',
          books: []
        });
      }),
      startWith({ loading: true, error: null, books: [] })
    );
  }
}
